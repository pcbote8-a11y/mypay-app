#!/usr/bin/env bash
# Script to generate a secure production release keystore for MyPay
set -e

KEYSTORE_NAME="release-keystore.jks"
KEY_ALIAS="mypay-release-key"
VALIDITY_DAYS=10000

echo "Generating release keystore for MyPay..."
keytool -genkey -v \
  -keystore "$KEYSTORE_NAME" \
  -alias "$KEY_ALIAS" \
  -keyalg RSA \
  -keysize 2048 \
  -validity $VALIDITY_DAYS \
  -dname "CN=MyPay, OU=Mobile, O=Sondip, L=Dhaka, ST=Dhaka, C=BD"

echo ""
echo "Keystore generated: $KEYSTORE_NAME"
echo "Alias: $KEY_ALIAS"
echo ""
echo "To view SHA-256 fingerprint for assetlinks.json / Play Console:"
echo "keytool -list -v -keystore $KEYSTORE_NAME -alias $KEY_ALIAS"
