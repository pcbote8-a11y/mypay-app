# MyPay - Android Studio Kotlin Project
Official Website-to-Android Native Hybrid Application for **https://mypay.sondip.shop**

## Highlights
- **100% Ads-Free**: Absolutely NO AdMob, NO Banner Ads, NO Interstitial Ads, NO Ad SDKs.
- **Modern Kotlin & Android 14 (API 34) Ready**: Built with AndroidX, Material 3, and modern Activity Result APIs.
- **Login & Cookie Session Persistence**: Automatic cookie synchronization and persistent local storage.
- **Pull to Refresh**: Native Android pull-to-refresh connected directly to the WebView.
- **Smart URL Handling**: 
  - Internal pages (mypay.sondip.shop) load in-app seamlessly.
  - External pages and OAuth (Google Login) open securely via Chrome Custom Tabs.
  - Native schemes supported: WhatsApp (`whatsapp://`, `wa.me`), Telegram (`tg://`, `t.me`), Phone (`tel:`), Email (`mailto:`), and UPI.
- **File & Camera Upload**: Multi-file chooser and direct camera photo capture with Android FileProvider.
- **Offline Mode**: Native offline screen with retry button and automatic network reconnection detection.
- **Centralized Config**: Change `WEBSITE_URL` in `Config.kt` at any time to reuse for other websites.
- **Mobile Friendly Cloud Build**: Includes ready-to-run GitHub Actions workflow (`.github/workflows/build-apk.yml`) to compile APK on cloud without a computer!

---

## 📱 How to Build on Mobile Phone (Without PC)

### Option 1: GitHub Actions (Recommended & Easiest)
1. Open [GitHub](https://github.com) on your phone browser and create a new repository.
2. Upload this project or push using git.
3. Go to the **Actions** tab on your GitHub repository.
4. The workflow **"Build Android APK & AAB"** will automatically compile the app using Java 17 and Gradle.
5. In 2-3 minutes, download the generated **`MyPay-Debug-APK`** or **`MyPay-Release-AAB`** from the **Artifacts** section directly on your phone!

### Option 2: Termux (Local build on phone)
1. Install **Termux** from F-Droid.
2. Run: `pkg update && pkg install openjdk-17`
3. Unzip project in Termux and run: `./gradlew assembleDebug`
4. APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

---

## 💻 How to Build in Android Studio (On PC/Laptop)

1. **Open the Project**:
   - Download the project ZIP and extract it.
   - Open Android Studio.
   - Click **File** -> **Open...** and select the extracted project folder.
   - Wait for Gradle sync to complete.

2. **Build Debug APK**:
   - In Android Studio: **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**
   - Or from Terminal:
     ```bash
     ./gradlew assembleDebug
     ```
   - Output location: `app/build/outputs/apk/debug/app-debug.apk`

3. **Build Signed Release APK**:
   - In Android Studio: **Build** -> **Generate Signed Bundle / APK...**
   - Select **APK** -> Click **Next**.
   - Create or select your keystore (`release-keystore.jks`).
   - Select **release** build variant and check V1/V2 signatures.
   - Click **Create**.
   - Output location: `app/build/outputs/apk/release/app-release.apk`

4. **Build Release AAB (Android App Bundle) for Google Play Console**:
   - In Android Studio: **Build** -> **Generate Signed Bundle / APK...**
   - Select **Android App Bundle** -> Click **Next**.
   - Enter your keystore credentials.
   - Select **release** variant -> Click **Finish**.
   - Output location: `app/build/outputs/bundle/release/app-release.aab`
   - Or from Terminal (with `key.properties` configured):
     ```bash
     ./gradlew bundleRelease
     ```

---

## App Links Setup (`assetlinks.json`)
To enable verified deep links so that URLs like `https://mypay.sondip.shop/login` automatically open in your app:
1. Extract your signing key SHA-256 fingerprint:
   ```bash
   keytool -list -v -keystore release-keystore.jks -alias mypay-release-key
   ```
2. Insert that fingerprint into the `assetlinks.json` file.
3. Upload `assetlinks.json` to your web server at:
   `https://mypay.sondip.shop/.well-known/assetlinks.json`
