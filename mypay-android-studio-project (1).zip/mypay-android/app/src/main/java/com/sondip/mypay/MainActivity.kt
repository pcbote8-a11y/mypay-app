package com.sondip.mypay

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var offlineLayout: View
    private lateinit var btnRetry: Button
    private lateinit var txtOfflineDesc: TextView

    private lateinit var webViewHelper: WebViewHelper
    private lateinit var networkHelper: NetworkHelper

    // File Upload Handlers
    var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraPhotoUri: Uri? = null
    private lateinit var fileChooserLauncher: ActivityResultLauncher<Intent>
    private lateinit var permissionLauncher: ActivityResultLauncher<Array<String>>

    // Double-press back to exit
    private var backPressedTime: Long = 0
    private val backToastInterval = 2000L

    override fun onCreate(savedInstanceState: Bundle?) {
        // Support Edge-to-Edge display
        WindowCompat.setDecorFitsSystemWindows(window, true)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupActivityResultLaunchers()
        setupNetworkObserver()
        setupWebView()
        setupBackNavigation()
        handleIntent(intent)
    }

    private fun initViews() {
        webView = findViewById(R.id.webView)
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)
        progressBar = findViewById(R.id.progressBar)
        offlineLayout = findViewById(R.id.offlineLayout)
        btnRetry = findViewById(R.id.btnRetry)
        txtOfflineDesc = findViewById(R.id.txtOfflineDesc)

        // Pull to refresh configuration
        swipeRefreshLayout.isEnabled = Config.ENABLE_PULL_TO_REFRESH
        swipeRefreshLayout.setColorSchemeResources(
            R.color.brand_primary,
            R.color.brand_secondary
        )
        swipeRefreshLayout.setOnRefreshListener {
            if (networkHelper.isConnected()) {
                webView.reload()
            } else {
                swipeRefreshLayout.isRefreshing = false
                showOfflineScreen(true)
            }
        }

        btnRetry.setOnClickListener {
            if (networkHelper.isConnected()) {
                showOfflineScreen(false)
                if (webView.url != null) {
                    webView.reload()
                } else {
                    webView.loadUrl(Config.getInitialUrl())
                }
            } else {
                Toast.makeText(this, getString(R.string.still_offline), Toast.LENGTH_SHORT).show()
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webViewHelper = WebViewHelper(this, webView, progressBar, swipeRefreshLayout)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = Config.ENABLE_JAVASCRIPT
        settings.domStorageEnabled = Config.ENABLE_DOM_STORAGE
        settings.databaseEnabled = Config.ENABLE_DATABASE_STORAGE
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadsImagesAutomatically = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false

        // Custom User-Agent
        val defaultUserAgent = settings.userAgentString
        settings.userAgentString = defaultUserAgent + Config.USER_AGENT_SUFFIX

        // Cookie Management (Crucial for Session & Login persistence)
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        // Attach custom clients
        webView.webViewClient = webViewHelper.createWebViewClient { isError ->
            showOfflineScreen(isError)
        }
        webView.webChromeClient = webViewHelper.createWebChromeClient()

        // Initial Load
        if (networkHelper.isConnected()) {
            showOfflineScreen(false)
            webView.loadUrl(Config.getInitialUrl())
        } else {
            showOfflineScreen(true)
        }
    }

    private fun setupNetworkObserver() {
        networkHelper = NetworkHelper(this) { isOnline ->
            runOnUiThread {
                if (isOnline) {
                    if (offlineLayout.visibility == View.VISIBLE) {
                        showOfflineScreen(false)
                        webView.reload()
                    }
                } else {
                    if (webView.url == null) {
                        showOfflineScreen(true)
                    }
                }
            }
        }
        networkHelper.startMonitoring()
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (offlineLayout.visibility == View.VISIBLE) {
                    if (webView.canGoBack()) {
                        showOfflineScreen(false)
                        webView.goBack()
                        return
                    }
                }

                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    if (backPressedTime + backToastInterval > System.currentTimeMillis()) {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    } else {
                        Toast.makeText(
                            this@MainActivity,
                            getString(R.string.press_back_again_to_exit),
                            Toast.LENGTH_SHORT
                        ).show()
                        backPressedTime = System.currentTimeMillis()
                    }
                }
            }
        })
    }

    private fun setupActivityResultLaunchers() {
        fileChooserLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (filePathCallback == null) return@registerForActivityResult

            var results: Array<Uri>? = null
            if (result.resultCode == RESULT_OK) {
                val data = result.data
                if (data != null && data.data != null) {
                    results = arrayOf(data.data!!)
                } else if (data != null && data.clipData != null) {
                    val count = data.clipData!!.itemCount
                    val uris = ArrayList<Uri>()
                    for (i in 0 until count) {
                        uris.add(data.clipData!!.getItemAt(i).uri)
                    }
                    results = uris.toTypedArray()
                } else if (cameraPhotoUri != null) {
                    // Check if file was captured by camera
                    results = arrayOf(cameraPhotoUri!!)
                }
            }
            filePathCallback?.onReceiveValue(results)
            filePathCallback = null
            cameraPhotoUri = null
        }

        permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false
            if (!cameraGranted && Config.ENABLE_CAMERA) {
                Toast.makeText(this, getString(R.string.camera_permission_info), Toast.LENGTH_SHORT).show()
            }
        }

        // Request permissions if needed
        checkAppPermissions()
    }

    private fun checkAppPermissions() {
        val permissionsToRequest = ArrayList<String>()
        if (Config.ENABLE_CAMERA && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }
        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    fun openFileChooser(callback: ValueCallback<Array<Uri>>, acceptTypes: Array<String>?, allowMultiple: Boolean) {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = callback

        val intents = ArrayList<Intent>()

        // Add Camera capture intent if enabled
        if (Config.ENABLE_CAMERA && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            val photoFile: File? = try {
                createImageFile()
            } catch (ex: IOException) {
                null
            }
            photoFile?.let {
                cameraPhotoUri = FileProvider.getUriForFile(
                    this,
                    "${applicationContext.packageName}.fileprovider",
                    it
                )
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri)
                intents.add(takePictureIntent)
            }
        }

        // Content Picker Intent
        val contentSelectionIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = if (!acceptTypes.isNullOrEmpty() && acceptTypes[0].isNotBlank()) acceptTypes[0] else "*/*"
            if (acceptTypes != null && acceptTypes.size > 1) {
                putExtra(Intent.EXTRA_MIME_TYPES, acceptTypes)
            }
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, allowMultiple)
        }

        val chooserIntent = Intent(Intent.ACTION_CHOOSER).apply {
            putExtra(Intent.EXTRA_INTENT, contentSelectionIntent)
            putExtra(Intent.EXTRA_TITLE, getString(R.string.select_file))
            if (intents.isNotEmpty()) {
                putExtra(Intent.EXTRA_INITIAL_INTENTS, intents.toTypedArray())
            }
        }

        fileChooserLauncher.launch(chooserIntent)
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("IMG_${timeStamp}_", ".jpg", storageDir)
    }

    fun showOfflineScreen(show: Boolean) {
        if (show) {
            offlineLayout.visibility = View.VISIBLE
            webView.visibility = View.GONE
            swipeRefreshLayout.isRefreshing = false
        } else {
            offlineLayout.visibility = View.GONE
            webView.visibility = View.VISIBLE
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        intent?.data?.let { uri ->
            val url = uri.toString()
            if (Config.isInternalUrl(url)) {
                webView.loadUrl(url)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        super.onDestroy()
        networkHelper.stopMonitoring()
        CookieManager.getInstance().flush()
        webView.destroy()
    }
}
