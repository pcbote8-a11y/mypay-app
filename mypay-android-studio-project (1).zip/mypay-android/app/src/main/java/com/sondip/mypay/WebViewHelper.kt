package com.sondip.mypay

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.view.View
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class WebViewHelper(
    private val activity: MainActivity,
    private val webView: WebView,
    private val progressBar: ProgressBar,
    private val swipeRefreshLayout: SwipeRefreshLayout
) {

    fun createWebViewClient(onOfflineState: (Boolean) -> Unit): WebViewClient {
        return object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                return handleUrlRouting(url)
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url == null) return false
                return handleUrlRouting(url)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (Config.ENABLE_PROGRESS_BAR) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = 10
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                swipeRefreshLayout.isRefreshing = false
                if (Config.ENABLE_PROGRESS_BAR) {
                    progressBar.visibility = View.GONE
                }
                // Flush cookies to persistent disk storage to maintain login state
                CookieManager.getInstance().flush()
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    val errorCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        error?.errorCode ?: 0
                    } else {
                        0
                    }
                    if (isNetworkErrorCode(errorCode)) {
                        onOfflineState(true)
                    }
                }
            }

            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(
                view: WebView?,
                handler: SslErrorHandler?,
                error: SslError?
            ) {
                // Strict SSL security: do not bypass SSL certificate errors in production
                handler?.cancel()
                Toast.makeText(
                    activity,
                    activity.getString(R.string.ssl_security_warning),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    fun createWebChromeClient(): WebChromeClient {
        return object : WebChromeClient() {

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (Config.ENABLE_PROGRESS_BAR) {
                    progressBar.progress = newProgress
                    if (newProgress >= 100) {
                        progressBar.visibility = View.GONE
                    } else {
                        progressBar.visibility = View.VISIBLE
                    }
                }
            }

            // Android File Upload Handler (Lollipop+)
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (!Config.ENABLE_FILE_UPLOAD || filePathCallback == null) {
                    return false
                }
                val acceptTypes = fileChooserParams?.acceptTypes
                val allowMultiple = fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE
                activity.openFileChooser(filePathCallback, acceptTypes, allowMultiple)
                return true
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                if (Config.ENABLE_LOCATION) {
                    callback?.invoke(origin, true, false)
                } else {
                    callback?.invoke(origin, false, false)
                }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    if (Config.ENABLE_CAMERA) {
                        request?.grant(request.resources)
                    } else {
                        request?.deny()
                    }
                }
            }
        }
    }

    private fun handleUrlRouting(url: String): Boolean {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase() ?: ""

        // 1. Handle External App Schemes (Phone, Email, WhatsApp, Telegram, UPI)
        when (scheme) {
            "tel" -> {
                launchExternalIntent(Intent(Intent.ACTION_DIAL, uri))
                return true
            }
            "mailto" -> {
                launchExternalIntent(Intent(Intent.ACTION_SENDTO, uri))
                return true
            }
            "sms" -> {
                launchExternalIntent(Intent(Intent.ACTION_SENDTO, uri))
                return true
            }
            "whatsapp", "tg" -> {
                launchExternalIntent(Intent(Intent.ACTION_VIEW, uri))
                return true
            }
            "upi" -> {
                // Payment Intent
                launchExternalIntent(Intent(Intent.ACTION_VIEW, uri))
                return true
            }
            "intent" -> {
                try {
                    val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                    if (intent != null) {
                        val packageManager = activity.packageManager
                        val info = packageManager.resolveActivity(intent, 0)
                        if (info != null) {
                            activity.startActivity(intent)
                        } else {
                            val fallbackUrl = intent.getStringExtra("browser_fallback_url")
                            if (fallbackUrl != null) {
                                webView.loadUrl(fallbackUrl)
                            }
                        }
                        return true
                    }
                } catch (e: Exception) {
                    return false
                }
            }
        }

        // 2. WhatsApp and Telegram Web Links
        val host = uri.host?.lowercase() ?: ""
        if (host.contains("api.whatsapp.com") || host.contains("wa.me") || host.contains("t.me") || host.contains("telegram.me")) {
            launchExternalIntent(Intent(Intent.ACTION_VIEW, uri))
            return true
        }

        // 3. Google OAuth & Social Logins (Google blocks insecure WebViews for OAuth)
        if (isOAuthLoginUrl(url)) {
            openChromeCustomTab(url)
            return true
        }

        // 4. Internal Domain Navigation (Website Content)
        if (Config.isInternalUrl(url)) {
            // Load inside WebView
            return false
        }

        // 5. External Web Links (Payment Gateways, External partners)
        if (Config.OPEN_EXTERNAL_LINKS) {
            openChromeCustomTab(url)
            return true
        }

        return false
    }

    private fun isOAuthLoginUrl(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains("accounts.google.com") ||
               lower.contains("appleid.apple.com") ||
               lower.contains("facebook.com/v") && lower.contains("dialog/oauth")
    }

    fun openChromeCustomTab(url: String) {
        try {
            val customTabsIntent = CustomTabsIntent.Builder()
                .setShowTitle(true)
                .setToolbarColor(ContextCompat.getColor(activity, R.color.brand_primary))
                .build()
            customTabsIntent.launchUrl(activity, Uri.parse(url))
        } catch (e: Exception) {
            // Fallback to default browser
            launchExternalIntent(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    private fun launchExternalIntent(intent: Intent) {
        try {
            activity.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                activity,
                activity.getString(R.string.no_app_found),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun isNetworkErrorCode(errorCode: Int): Boolean {
        return errorCode == WebViewClient.ERROR_HOST_LOOKUP ||
               errorCode == WebViewClient.ERROR_CONNECT ||
               errorCode == WebViewClient.ERROR_TIMEOUT ||
               errorCode == WebViewClient.ERROR_FAILED_SSL_HANDSHAKE
    }
}
