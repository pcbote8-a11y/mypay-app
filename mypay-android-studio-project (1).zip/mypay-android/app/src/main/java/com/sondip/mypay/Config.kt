package com.sondip.mypay

/**
 * Centralized Configuration for MyPay
 *
 * Easily customize the application by changing values in this file.
 * To point to another website, simply change WEBSITE_URL.
 */
object Config {
    // Application Information
    const val APP_NAME = "MyPay"
    const val WEBSITE_URL = "https://mypay.sondip.shop"
    const val START_PATH = "/"

    // Feature Flags
    const val ENABLE_JAVASCRIPT = true
    const val ENABLE_PULL_TO_REFRESH = true
    const val ENABLE_PROGRESS_BAR = true
    const val ENABLE_FILE_UPLOAD = true
    const val ENABLE_CAMERA = true
    const val ENABLE_LOCATION = false
    const val OPEN_EXTERNAL_LINKS = true
    const val ENABLE_DEBUG_LOGGING = true

    // Cache and Session Management
    const val ENABLE_DOM_STORAGE = true
    const val ENABLE_DATABASE_STORAGE = true
    const val CLEAR_CACHE_ON_EXIT = false

    // App Links / Supported Internal Domains
    val INTERNAL_DOMAINS = arrayOf(
        "mypay.sondip.shop",
        "www.mypay.sondip.shop"
    )

    // User Agent Prefix / Custom identifier
    const val USER_AGENT_SUFFIX = " MyPayApp/1.0 (Android Native Hybrid)"

    // Helper: Build Full Start URL
    fun getInitialUrl(): String {
        return if (START_PATH.isNotEmpty() && START_PATH != "/") {
            "$WEBSITE_URL$START_PATH"
        } else {
            WEBSITE_URL
        }
    }

    // Helper: Check if a URL is an internal domain
    fun isInternalUrl(url: String): Boolean {
        return try {
            val uri = android.net.Uri.parse(url)
            val host = uri.host ?: return false
            INTERNAL_DOMAINS.any { internalDomain ->
                host.equals(internalDomain, ignoreCase = true) || host.endsWith(".$internalDomain", ignoreCase = true)
            }
        } catch (e: Exception) {
            false
        }
    }
}
