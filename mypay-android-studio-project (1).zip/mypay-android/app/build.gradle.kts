plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.sondip.mypay"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sondip.mypay"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        create("release") {
            // Secure Release Signing: Configured via key.properties or environment variables
            val keystorePropertiesFile = rootProject.file("key.properties")
            if (keystorePropertiesFile.exists()) {
                val properties = java.util.Properties()
                properties.load(keystorePropertiesFile.inputStream())

                storeFile = file(properties.getProperty("storeFile") ?: "release.jks")
                storePassword = properties.getProperty("storePassword") ?: ""
                keyAlias = properties.getProperty("keyAlias") ?: ""
                keyPassword = properties.getProperty("keyPassword") ?: ""
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Use release signing config if available, fallback to debug for testing
            val keyProps = rootProject.file("key.properties")
            if (keyProps.exists()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = false
    }
}

dependencies {
    // AndroidX & UI
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.coordinatorlayout:coordinatorlayout:1.2.0")

    // SwipeRefreshLayout for Pull-to-Refresh
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")

    // Chrome Custom Tabs for OAuth & External Links
    implementation("androidx.browser:browser:1.8.0")

    // Note: STRICTLY 100% Ads-Free. No AdMob, no advertising dependencies.
}
